Admin Account:
Email : admin@edoc.com
Password : 123


Student Accounts :
Format -
Email
Password

maruf@gmail.com
123

hasan@gmail.com
123

sadia@gmail.com
123

tahsin@gmail.com
123

fresherboy1@gmail.com
123

freshergirl1@gmail.com
123


